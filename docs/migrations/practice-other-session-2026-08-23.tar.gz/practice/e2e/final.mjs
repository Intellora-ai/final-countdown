import { chromium } from '@playwright/test'
const b = await chromium.launch()
const p = await b.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 })
await p.goto('http://localhost:4310/practice', { waitUntil: 'networkidle' })
const ch = p.locator('[data-node="chapter"][data-id="eco-1"]')
await ch.waitFor({ timeout: 20000 })
await ch.hover(); await p.waitForTimeout(400)
await ch.click(); await p.waitForTimeout(800)
await p.screenshot({ path: '/tmp/pshots/4-final.png' })
console.log('FINAL ' + JSON.stringify(await p.evaluate(() => ({
  chapters: document.querySelectorAll('[data-node="chapter"]').length,
  topics: document.querySelectorAll('[data-node="topic"]').length,
  panel: !!document.querySelector('.detail-panel'),
  title: document.querySelector('.detail-panel h2')?.textContent,
}))))
await b.close()
