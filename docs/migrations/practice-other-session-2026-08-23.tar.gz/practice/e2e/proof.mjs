import { chromium } from '@playwright/test'
const [, , out] = process.argv
const b = await chromium.launch()
const p = await b.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 3 })
const errs = []
p.on('pageerror', (e) => errs.push(e.message))
await p.goto('http://localhost:4310/practice', { waitUntil: 'networkidle' })
const ch = p.locator('[data-node="chapter"][data-id="eco-1"]')
await ch.waitFor({ timeout: 20000 })
await ch.hover()                      // hover expands the chapter
await p.waitForTimeout(700)

const state = await p.evaluate(() => {
  const vw = innerWidth, vh = innerHeight
  const node = document.querySelector('[data-id="eco-1-zzz-proof"]')
  const dot = node?.querySelector('circle')
  const r = dot?.getBoundingClientRect()
  const parent = document.querySelector('[data-id="eco-1"] .dot')?.getBoundingClientRect()
  // the edge whose endpoints are chapter -> fake topic
  const edge = [...document.querySelectorAll('.edge')].some((l) => {
    const bb = l.getBoundingClientRect()
    return r && bb.left <= r.right + 2 && bb.right >= r.left - 2
  })
  return {
    present: !!node,
    label: node?.querySelector('text')?.textContent ?? null,
    insideViewport: !!r && r.left >= 0 && r.top >= 0 && r.right <= vw && r.bottom <= vh,
    hasEdgeToParent: edge,
    distanceToChapterPx: r && parent
      ? Math.round(Math.hypot(r.x - parent.x, r.y - parent.y)) : null,
    topics: document.querySelectorAll('[data-node="topic"]').length,
  }
})

// Clip a legible crop around the chapter rather than moving the camera.
const box = await ch.boundingBox()
const pad = 150
await p.screenshot({
  path: out,
  clip: {
    x: Math.max(0, box.x - pad), y: Math.max(0, box.y - pad),
    width: Math.min(1440 - Math.max(0, box.x - pad), box.width + pad * 2),
    height: Math.min(900 - Math.max(0, box.y - pad), box.height + pad * 2),
  },
})
console.log('PROOF ' + JSON.stringify(state))
console.log('ERRORS ' + JSON.stringify(errs.slice(0, 3)))
await b.close()
