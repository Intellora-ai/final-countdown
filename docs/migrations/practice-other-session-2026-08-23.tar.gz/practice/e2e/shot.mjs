import { chromium } from '@playwright/test'
const [, , out, label] = process.argv
const b = await chromium.launch()
const p = await b.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 })
const errs = []
p.on('pageerror', (e) => errs.push(e.message))
p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()) })
await p.goto('http://localhost:4310/practice', { waitUntil: 'networkidle' })
await p.waitForSelector('[data-node="chapter"]', { timeout: 20000 })
if (label) {
  // Open the chapter that owns the item we are proving, so its topics show.
  const ch = p.locator('[data-node="chapter"][data-id="eco-1"]')
  await ch.hover()
  await p.waitForTimeout(400)
  await ch.click()
  await p.waitForTimeout(600)
}
await p.waitForTimeout(900)
const counts = await p.evaluate(() => ({
  chapters: document.querySelectorAll('[data-node="chapter"]').length,
  topics: document.querySelectorAll('[data-node="topic"]').length,
  edges: document.querySelectorAll('.edge').length,
  hasFake: !!document.querySelector('[data-id="eco-1-zzz-proof"]'),
}))
await p.screenshot({ path: out, fullPage: false })
console.log('COUNTS ' + JSON.stringify(counts))
console.log('ERRORS ' + JSON.stringify(errs.slice(0, 3)))
await b.close()
