import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Practice',
  description: 'A curriculum map you practise from.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
