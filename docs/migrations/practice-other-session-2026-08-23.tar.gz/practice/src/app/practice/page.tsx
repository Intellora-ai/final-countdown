'use client'

import { useMemo, useState } from 'react'
import { CURRICULUM } from '@/data/curriculum'
import { buildLayout, type LayoutNode } from '@/layout/buildLayout'
import { InfiniteCanvas } from '@/components/InfiniteCanvas'
import { ConstellationMap } from '@/components/ConstellationMap'
import { DetailPanel } from '@/components/DetailPanel'
import { usePracticeStore } from '@/store/practiceStore'

/* THE PRACTICE MAP.
 *
 * Deliberately sparse. The brief asked for a specific list of things to be
 * gone: the "practice anything" button, mix and surprise, the left rail of
 * learn / revise / practice / progress / settings, and the row of suggestion
 * chips (fix something, get faster, go deeper, challenge yourself, prepare,
 * practice again, exam prep). None of them are here. What remains is the map,
 * the continue card, and the panel that opens when a star is clicked.
 *
 * THE LAYOUT IS BUILT ONCE, from the curriculum, and every child reads the
 * same object. Nothing downstream recomputes a position or caches one, so
 * there is exactly one answer to "where is eco-3?" on the page.
 */

export default function PracticePage() {
  /* Memoised on the curriculum alone: buildLayout is pure, so the only thing
   * that could change the answer is the data. */
  const layout = useMemo(() => buildLayout(CURRICULUM), [])

  const [selectedId, setSelectedId] = useState<string | null>(null)
  const lastPractised = usePracticeStore((s) => s.lastPractised)
  const markPractised = usePracticeStore((s) => s.markPractised)

  const selected = selectedId ? layout.byId.get(selectedId) ?? null : null

  /* The most recently practised chapter, resolved through the layout so a
   * chapter deleted from the curriculum cannot linger in this card. */
  const resume = useMemo(() => {
    const entries = Object.entries(lastPractised)
      .filter(([id]) => layout.byId.has(id))
      .sort((a, b) => Date.parse(b[1]) - Date.parse(a[1]))
    const first = entries[0]
    return first ? layout.byId.get(first[0]) ?? null : null
  }, [lastPractised, layout])

  const start = (node: LayoutNode) => {
    /* The session screen is a later piece of work. Recording the attempt is
     * what makes the map grow, so that part is real now: practising a chapter
     * marks its topics, practising a topic marks itself. */
    const topicIds = node.kind === 'chapter'
      ? (layout.childrenOf.get(node.id) ?? []).map((t) => t.id)
      : [node.id]
    const chapterId = node.kind === 'chapter' ? node.id : (node.parentId ?? node.id)
    markPractised(chapterId, topicIds, new Date().toISOString())
    setSelectedId(null)
  }

  return (
    <main className="practice-page">
      <InfiniteCanvas
        world={layout.bounds}
        className="map-host"
        overlay={
          <>
            <section className="continue-card" aria-label="Continue practising">
              <h1>Continue practising</h1>
              {resume ? (
                <button type="button" className="resume" onClick={() => setSelectedId(resume.id)}>
                  <span className="resume-title">{resume.label}</span>
                  <span className="resume-meta">
                    {resume.chapterNumber !== null ? `Chapter ${resume.chapterNumber}` : 'Topic'}
                    {' · '}resume
                  </span>
                </button>
              ) : (
                <p className="empty">Nothing yet. Pick a chapter on the map to start.</p>
              )}
            </section>

            {selected && (
              <DetailPanel
                layout={layout}
                node={selected}
                onClose={() => setSelectedId(null)}
                onStart={start}
              />
            )}
          </>
        }
      >
        <ConstellationMap
          layout={layout}
          selectedId={selectedId}
          onSelect={(n) => setSelectedId(n.id)}
        />
      </InfiniteCanvas>
    </main>
  )
}
