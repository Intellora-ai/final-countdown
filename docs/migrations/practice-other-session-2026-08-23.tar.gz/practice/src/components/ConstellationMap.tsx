'use client'

import { useCallback, useMemo } from 'react'
import { endpointsOf, type Layout, type LayoutNode } from '@/layout/buildLayout'
import { usePracticeStore } from '@/store/practiceStore'

/* THE MAP. IT INVENTS NO POSITIONS.
 *
 * Every cx, cy, x1, y1 below traces to a node that buildLayout() produced.
 * There is no coordinate literal here and no per-item offset table; if a node
 * is in the wrong place the fix is in the layout, which is the only file that
 * decides where anything goes.
 *
 * EDGES RESOLVE THROUGH byId, ALWAYS. An edge carries `{from, to}` ids and
 * nothing else, so a line is drawn from whatever the map currently says those
 * two nodes are. That is what makes it impossible for a connector to point at
 * where a node used to be: there is no cached endpoint to go stale, and
 * `endpointsOf` returns null rather than drawing into space if either end has
 * gone.
 *
 * SIZES ARE DIVIDED BY THE CAMERA SCALE nowhere. Strokes and label sizes are
 * stated in world units and scale with the map, because a constellation that
 * keeps its label size while zooming stops reading as a starfield.
 */

interface Props {
  layout: Layout
  selectedId: string | null
  onSelect: (node: LayoutNode) => void
}

/** Faint, so the labels sit behind the stars rather than competing with them. */
const SUBJECT_LABEL_SIZE = 26
const CHAPTER_LABEL_SIZE = 7
const TOPIC_LABEL_SIZE = 4.6

export function ConstellationMap({ layout, selectedId, onSelect }: Props) {
  const expanded = usePracticeStore((s) => s.expanded)
  const practised = usePracticeStore((s) => s.practisedTopics)
  const setChapterExpanded = usePracticeStore((s) => s.setChapterExpanded)

  const practisedSet = useMemo(() => new Set(practised), [practised])

  /* A chapter shows its topics when it has been opened, or when it is the
   * selected one. Untouched chapters use the closed default.
   *
   * useCallback rather than a plain function, so the memo below can depend on
   * it honestly. The first version declared `isOpen` inline and silenced
   * exhaustive-deps with a disable comment — which is a note saying "the
   * dependency list is wrong and I know". If a dependency array needs
   * suppressing, the value it depends on is the thing to fix. */
  const isOpen = useCallback(
    (chapterId: string) => expanded[chapterId] ?? (selectedId === chapterId),
    [expanded, selectedId],
  )

  /* Visibility is decided here and nowhere else, so an edge and its node can
   * never disagree about whether they are on screen. */
  const visible = useMemo(() => {
    const set = new Set<string>()
    for (const n of layout.nodes) {
      if (n.kind === 'subject' || n.kind === 'chapter') { set.add(n.id); continue }
      if (n.parentId && isOpen(n.parentId)) set.add(n.id)
    }
    return set
  }, [layout, isOpen])

  const { minX, minY, width, height } = layout.bounds

  return (
    <svg
      width={width}
      height={height}
      viewBox={`${minX} ${minY} ${width} ${height}`}
      className="constellation"
      role="tree"
      aria-label="Curriculum map"
    >
      <defs>
        <radialGradient id="starGlow">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.55" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Subject names, set large and dim, behind everything. */}
      {layout.nodes.filter((n) => n.kind === 'subject').map((s) => (
        <text
          key={s.id}
          x={s.x} y={s.y}
          className="subject-label"
          style={{ fontSize: SUBJECT_LABEL_SIZE }}
          textAnchor="middle"
        >
          {s.label.toUpperCase()}
        </text>
      ))}

      {/* Connectors. Endpoints looked up live — never stored on the edge. */}
      <g className="edges">
        {layout.edges.map((edge) => {
          const ends = endpointsOf(layout, edge)
          if (!ends) return null
          const { from, to } = ends
          if (!visible.has(from.id) || !visible.has(to.id)) return null
          /* A subject has no dot, so its lines would radiate from a text
           * baseline. Skipping them keeps the clusters looking like
           * constellations rather than asterisks. */
          if (from.kind === 'subject') return null
          return (
            <line
              key={edge.id}
              x1={from.x} y1={from.y} x2={to.x} y2={to.y}
              className="edge"
            />
          )
        })}
      </g>

      {/* Chapters, then topics, so a topic never hides under its parent. */}
      <g className="chapters">
        {layout.nodes.filter((n) => n.kind === 'chapter').map((c) => {
          const open = isOpen(c.id)
          const selected = selectedId === c.id
          const kids = layout.childrenOf.get(c.id) ?? []
          const done = kids.filter((k) => practisedSet.has(k.id)).length
          return (
            <g
              key={c.id}
              data-node="chapter"
              data-id={c.id}
              className={`node chapter${selected ? ' is-selected' : ''}${open ? ' is-open' : ''}`}
              role="treeitem"
              aria-expanded={open}
              aria-label={`Chapter ${c.chapterNumber}: ${c.label}`}
              tabIndex={0}
              onMouseEnter={() => setChapterExpanded(c.id, true)}
              onClick={(e) => { e.stopPropagation(); onSelect(c) }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(c) }
              }}
            >
              <circle cx={c.x} cy={c.y} r={c.r * 4} fill="url(#starGlow)" className="glow" />
              <circle cx={c.x} cy={c.y} r={c.r} className="dot" />
              <text x={c.x} y={c.y + 13} textAnchor="middle" className="ch-num"
                style={{ fontSize: CHAPTER_LABEL_SIZE * 0.75 }}>
                CH {c.chapterNumber}{done > 0 ? ` · ${done}/${kids.length}` : ''}
              </text>
              <text x={c.x} y={c.y + 22} textAnchor="middle" className="ch-title"
                style={{ fontSize: CHAPTER_LABEL_SIZE }}>
                {wrap(c.label, c.x)}
              </text>
            </g>
          )
        })}
      </g>

      <g className="topics">
        {layout.nodes.filter((n) => n.kind === 'topic' && visible.has(n.id)).map((t) => (
          <g
            key={t.id}
            data-node="topic"
            data-id={t.id}
            className={`node topic${selectedId === t.id ? ' is-selected' : ''}${practisedSet.has(t.id) ? ' is-done' : ''}`}
            role="treeitem"
            aria-label={`Topic: ${t.label}`}
            tabIndex={0}
            onClick={(e) => { e.stopPropagation(); onSelect(t) }}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onSelect(t) }
            }}
          >
            <circle cx={t.x} cy={t.y} r={t.r} className="dot" />
            <text x={t.x} y={t.y - 6} textAnchor="middle" className="tp-title"
              style={{ fontSize: TOPIC_LABEL_SIZE }}>
              {t.label}
            </text>
          </g>
        ))}
      </g>
    </svg>
  )
}

/** Chapter titles run long, and one line of them overlaps the neighbouring
 *  star at any readable size. Split onto two.
 *
 *  Each tspan repeats `x` explicitly. SVG does not inherit the parent text's x
 *  on a line break the way HTML would: a tspan with only `dy` continues from
 *  where the previous one ENDED, so the second line would start at the right
 *  edge of the first and march off to the side. Passing x is what makes them
 *  stack. */
function wrap(label: string, x: number): React.ReactNode {
  const words = label.split(' ')
  if (words.length <= 3) return label
  const mid = Math.ceil(words.length / 2)
  return (
    <>
      <tspan x={x} dy={0}>{words.slice(0, mid).join(' ')}</tspan>
      <tspan x={x} dy="1.15em">{words.slice(mid).join(' ')}</tspan>
    </>
  )
}
