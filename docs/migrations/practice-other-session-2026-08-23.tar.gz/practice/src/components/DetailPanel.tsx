'use client'

import type { Layout, LayoutNode } from '@/layout/buildLayout'
import {
  usePracticeStore, QUESTION_MAX, QUESTION_MIN, TIMER_PRESETS,
} from '@/store/practiceStore'

/* WHAT OPENS WHEN A STAR IS CLICKED.
 *
 * The same panel serves a chapter and a topic, because the brief was explicit
 * that both are clickable and both start a session. What differs is scope: a
 * chapter practises all of its topics, a topic practises itself. Everything
 * else — the timer, the question count, the last-practised line — is identical,
 * so it is one component rather than two that drift apart.
 *
 * THE COUNT STOPS AT FIFTEEN. That ceiling is a product decision, not a
 * rendering detail, so it lives in the store beside the value it bounds and is
 * clamped on write. A slider that can only reach fifteen is not enough on its
 * own: a persisted value from an older build could arrive higher, and the
 * clamp in the store is what makes that harmless.
 */

interface Props {
  layout: Layout
  node: LayoutNode
  onClose: () => void
  onStart: (node: LayoutNode) => void
}

export function DetailPanel({ layout, node, onClose, onStart }: Props) {
  const prefs = usePracticeStore((s) => s.prefs)
  const setPrefs = usePracticeStore((s) => s.setPrefs)
  const lastPractised = usePracticeStore((s) => s.lastPractised)
  const practised = usePracticeStore((s) => s.practisedTopics)

  const isChapter = node.kind === 'chapter'
  const chapter = isChapter ? node : (node.parentId ? layout.byId.get(node.parentId) : undefined)
  const subject = layout.byId.get(node.subjectId)
  const topics = isChapter ? (layout.childrenOf.get(node.id) ?? []) : []
  const doneCount = topics.filter((t) => practised.includes(t.id)).length

  /* A chapter's history is the chapter's; a topic borrows its chapter's, since
   * a session started from a topic still counts as practising that chapter. */
  const historyKey = chapter?.id ?? node.id
  const last = lastPractised[historyKey]

  return (
    <aside className="detail-panel" aria-label={`${node.label} practice options`}>
      <header>
        <p className="crumb">
          {subject ? subject.label.toUpperCase() : ''}
          {chapter ? <> <span aria-hidden="true">·</span> CHAPTER {chapter.chapterNumber}</> : null}
        </p>
        <button type="button" className="close" onClick={onClose} aria-label="Close panel">×</button>
        <h2>{node.label}</h2>
        <p className="meta">
          Last practised <strong>{last ? relativeDay(last) : 'never'}</strong>
          {isChapter ? <> <span aria-hidden="true">·</span> {doneCount}/{topics.length} topics</> : null}
          {!isChapter ? <> <span aria-hidden="true">·</span> single topic</> : null}
        </p>
      </header>

      <div className="field">
        <div className="field-head">
          <label htmlFor="timer-toggle">Timer</label>
          <button
            id="timer-toggle"
            type="button"
            role="switch"
            aria-checked={prefs.timerOn}
            className={`switch${prefs.timerOn ? ' is-on' : ''}`}
            onClick={() => setPrefs({ timerOn: !prefs.timerOn })}
          >
            <span className="knob" />
          </button>
        </div>

        <div className="presets" role="group" aria-label="Timer length">
          {TIMER_PRESETS.map((m) => (
            <button
              key={m}
              type="button"
              disabled={!prefs.timerOn}
              aria-pressed={prefs.timerMinutes === m}
              className={`preset${prefs.timerMinutes === m ? ' is-active' : ''}`}
              onClick={() => setPrefs({ timerMinutes: m })}
            >
              {m}m
            </button>
          ))}
        </div>
      </div>

      <div className="field">
        <div className="field-head">
          <label htmlFor="question-count">Questions</label>
          <output htmlFor="question-count" className="count">{prefs.questionCount}</output>
        </div>
        <input
          id="question-count"
          type="range"
          min={QUESTION_MIN}
          max={QUESTION_MAX}
          step={1}
          value={prefs.questionCount}
          onChange={(e) => setPrefs({ questionCount: Number(e.target.value) })}
        />
        <div className="scale">
          <span>{QUESTION_MIN}</span>
          <span>{QUESTION_MAX} max</span>
        </div>
      </div>

      {isChapter && topics.length > 0 && (
        <ul className="topic-list" aria-label="Topics in this chapter">
          {topics.map((t) => (
            <li key={t.id} className={practised.includes(t.id) ? 'is-done' : undefined}>
              <span className="tick" aria-hidden="true">{practised.includes(t.id) ? '●' : '○'}</span>
              {t.label}
            </li>
          ))}
        </ul>
      )}

      <footer>
        <button type="button" className="start" onClick={() => onStart(node)}>
          Start practice
        </button>
        <p className="summary">
          {prefs.questionCount} question{prefs.questionCount === 1 ? '' : 's'}
          {prefs.timerOn ? ` · ${prefs.timerMinutes} minutes` : ' · no timer'}
        </p>
      </footer>
    </aside>
  )
}

/* Days rather than a timestamp: "3 days ago" is what a student is actually
 * asking, and it needs no locale handling. Computed from the stored ISO string
 * at render, never stored — a saved "2 days ago" would be wrong tomorrow. */
function relativeDay(iso: string): string {
  const then = Date.parse(iso)
  if (Number.isNaN(then)) return 'never'
  const days = Math.floor((Date.now() - then) / 86_400_000)
  if (days <= 0) return 'today'
  if (days === 1) return 'yesterday'
  if (days < 30) return `${days} days ago`
  return 'over a month ago'
}
