'use client'

import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react'

/* PAN AND ZOOM OVER A WORLD OF UNKNOWN SIZE.
 *
 * The map has no fixed dimensions — buildLayout() measures the content and
 * reports bounds — so this cannot be a viewport over a known 1408x768 board.
 * It takes whatever world it is handed and fits it, which is what lets the
 * curriculum grow without anyone re-tuning a camera.
 *
 * WHY THE FIT IS MEASURED, NOT COMPUTED FROM window.innerWidth. The map is a
 * panel inside a page, not the page. Reading the window would be right only
 * while the map happened to fill the screen, and wrong the moment a side panel
 * opened. A ResizeObserver on the element itself is the only measurement that
 * stays true.
 *
 * WHEEL SEMANTICS. Ctrl/⌘ + wheel and a trackpad pinch both arrive as a wheel
 * event with ctrlKey set; that is zoom. A bare wheel is a two-finger scroll and
 * pans. Zoom is anchored under the pointer, so the thing you are looking at
 * stays under the cursor instead of sliding away as the scale changes.
 */

export interface Camera { x: number; y: number; scale: number }
/* Only a SIZE, deliberately.
 *
 * The first version also took minX/minY and subtracted them when centring, and
 * the map landed off-screen to the bottom-right. The child is an <svg> whose
 * viewBox already maps world minX..maxX onto a box starting at the layout
 * origin, so the offset was being applied twice — once by the viewBox and
 * again by the camera. Whoever owns the viewBox owns the offset; this
 * component only ever pans and zooms a box of a given size. */
export interface WorldBounds { width: number; height: number }

export const MIN_SCALE = 0.25
export const MAX_SCALE = 4

interface Props {
  world: WorldBounds
  children: ReactNode
  className?: string
  /** Rendered outside the transformed layer, in screen space. */
  overlay?: ReactNode
}

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n))

export function InfiniteCanvas({ world, children, className, overlay }: Props) {
  const hostRef = useRef<HTMLDivElement>(null)
  const [size, setSize] = useState<{ w: number; h: number } | null>(null)
  const [camera, setCamera] = useState<Camera | null>(null)
  const [panning, setPanning] = useState(false)
  const dragRef = useRef<{ px: number; py: number; cx: number; cy: number } | null>(null)

  /* Measure the element, never the window. */
  useEffect(() => {
    const el = hostRef.current
    if (!el) return
    const ro = new ResizeObserver(([entry]) => {
      if (!entry) return
      const { width, height } = entry.contentRect
      if (width > 0 && height > 0) setSize({ w: width, h: height })
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  /* Fit once, as soon as there is a real measurement AND a real world. Not on
   * every world change: refitting mid-session would yank the map out from
   * under a student who had panned somewhere deliberately. */
  const fitted = useRef(false)
  useEffect(() => {
    if (fitted.current || !size || world.width <= 0 || world.height <= 0) return
    const scale = clamp(
      Math.min(size.w / world.width, size.h / world.height) * 0.92,
      MIN_SCALE, MAX_SCALE,
    )
    setCamera({
      scale,
      x: size.w / 2 - (world.width / 2) * scale,
      y: size.h / 2 - (world.height / 2) * scale,
    })
    fitted.current = true
  }, [size, world])

  const onWheel = useCallback((e: React.WheelEvent) => {
    if (!camera) return
    e.preventDefault()
    const host = hostRef.current
    if (!host) return

    if (e.ctrlKey || e.metaKey) {
      const rect = host.getBoundingClientRect()
      const px = e.clientX - rect.left
      const py = e.clientY - rect.top
      const next = clamp(camera.scale * Math.exp(-e.deltaY * 0.0016), MIN_SCALE, MAX_SCALE)
      /* Keep the world point under the cursor fixed while the scale changes. */
      const wx = (px - camera.x) / camera.scale
      const wy = (py - camera.y) / camera.scale
      setCamera({ scale: next, x: px - wx * next, y: py - wy * next })
      return
    }
    setCamera({ ...camera, x: camera.x - e.deltaX, y: camera.y - e.deltaY })
  }, [camera])

  const onPointerDown = useCallback((e: React.PointerEvent) => {
    /* Left button on empty space only. A drag that started on a node is that
     * node's click, not a pan. */
    if (e.button !== 0 || !camera) return
    const target = e.target as HTMLElement
    if (target.closest('[data-node]')) return
    ;(e.currentTarget as HTMLElement).setPointerCapture(e.pointerId)
    dragRef.current = { px: e.clientX, py: e.clientY, cx: camera.x, cy: camera.y }
    setPanning(true)
  }, [camera])

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    const d = dragRef.current
    if (!d || !camera) return
    setCamera({ ...camera, x: d.cx + (e.clientX - d.px), y: d.cy + (e.clientY - d.py) })
  }, [camera])

  const endPan = useCallback(() => { dragRef.current = null; setPanning(false) }, [])

  const zoomBy = useCallback((factor: number) => {
    if (!camera || !size) return
    const next = clamp(camera.scale * factor, MIN_SCALE, MAX_SCALE)
    const cx = size.w / 2, cy = size.h / 2
    const wx = (cx - camera.x) / camera.scale
    const wy = (cy - camera.y) / camera.scale
    setCamera({ scale: next, x: cx - wx * next, y: cy - wy * next })
  }, [camera, size])

  const resetView = useCallback(() => { fitted.current = false; setSize((s) => (s ? { ...s } : s)) }, [])

  return (
    <div
      ref={hostRef}
      className={className}
      data-canvas="infinite"
      data-panning={panning ? 'true' : 'false'}
      data-scale={camera ? camera.scale.toFixed(3) : undefined}
      onWheel={onWheel}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endPan}
      onPointerCancel={endPan}
      style={{
        position: 'relative', overflow: 'hidden', touchAction: 'none',
        cursor: panning ? 'grabbing' : 'grab',
      }}
    >
      {camera && (
        <div
          data-canvas="world"
          style={{
            position: 'absolute', top: 0, left: 0,
            transformOrigin: '0 0',
            transform: `translate(${camera.x}px, ${camera.y}px) scale(${camera.scale})`,
            /* No transition while dragging: a tween on a pointer-driven value
             * reads as lag, not polish. */
            transition: panning ? 'none' : 'transform 140ms ease-out',
            willChange: 'transform',
          }}
        >
          {children}
        </div>
      )}

      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <div style={{ pointerEvents: 'auto' }}>{overlay}</div>
      </div>

      <div className="zoom-controls" role="group" aria-label="Zoom">
        <button type="button" onClick={() => zoomBy(1.25)} aria-label="Zoom in">+</button>
        <button type="button" onClick={() => zoomBy(1 / 1.25)} aria-label="Zoom out">−</button>
        <button type="button" onClick={resetView} aria-label="Fit map to screen">⤢</button>
      </div>
    </div>
  )
}
