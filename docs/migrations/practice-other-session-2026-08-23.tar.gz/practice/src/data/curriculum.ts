/* THE ONE DATA FILE.
 *
 * Content and relationships only. There is deliberately no x, no y, no width,
 * no angle and no radius anywhere below, and no fixed canvas size. Every
 * position on screen is computed from this file by buildLayout(), so the map
 * cannot disagree with the curriculum: there is only one place the curriculum
 * is written down.
 *
 * THE TEST THAT MATTERS: add a subject, a chapter or a topic here, change
 * nothing else, and it appears on the map correctly placed and correctly
 * joined to its parent. If that ever stops being true, the layout has grown a
 * second source of truth and the bug is there, not here.
 *
 * A note on ids: they are stable, human-readable and never reused. The layout
 * seeds its jitter from the id, so an item's exact position is a property of
 * its NAME rather than of its position in this array. Renaming an id moves a
 * node; reordering the array does not.
 */

export interface Subject {
  readonly id: string
  readonly name: string
}

export interface Chapter {
  readonly id: string
  readonly subjectId: string
  /** Printed on the node as "CH 3". Ordering only — never a coordinate. */
  readonly number: number
  readonly title: string
}

export interface Topic {
  readonly id: string
  readonly chapterId: string
  readonly title: string
}

export interface Curriculum {
  readonly subjects: readonly Subject[]
  readonly chapters: readonly Chapter[]
  readonly topics: readonly Topic[]
}

const subjects: readonly Subject[] = [
  { id: 'economics', name: 'Economics' },
  { id: 'accountancy', name: 'Accountancy' },
  { id: 'business-studies', name: 'Business Studies' },
  { id: 'applied-maths', name: 'Applied Mathematics' },
]

const chapters: readonly Chapter[] = [
  // ── Economics ────────────────────────────────────────────────────────────
  { id: 'eco-1', subjectId: 'economics', number: 1, title: 'Introduction to Microeconomics' },
  { id: 'eco-2', subjectId: 'economics', number: 2, title: "Consumer's Equilibrium and Demand" },
  { id: 'eco-3', subjectId: 'economics', number: 3, title: 'Producer Behaviour and Supply' },
  { id: 'eco-4', subjectId: 'economics', number: 4, title: 'Forms of Market and Price Determination' },
  { id: 'eco-5', subjectId: 'economics', number: 5, title: 'National Income and Related Aggregates' },
  { id: 'eco-6', subjectId: 'economics', number: 6, title: 'Money and Banking' },
  { id: 'eco-7', subjectId: 'economics', number: 7, title: 'Determination of Income and Employment' },
  { id: 'eco-8', subjectId: 'economics', number: 8, title: 'Government Budget and the Economy' },

  // ── Accountancy ──────────────────────────────────────────────────────────
  { id: 'acc-1', subjectId: 'accountancy', number: 1, title: 'Accounting for Partnership Firms' },
  { id: 'acc-2', subjectId: 'accountancy', number: 2, title: 'Reconstitution of Partnership' },
  { id: 'acc-3', subjectId: 'accountancy', number: 3, title: 'Dissolution of Partnership Firm' },
  { id: 'acc-4', subjectId: 'accountancy', number: 4, title: 'Accounting for Share Capital' },
  { id: 'acc-5', subjectId: 'accountancy', number: 5, title: 'Issue and Redemption of Debentures' },
  { id: 'acc-6', subjectId: 'accountancy', number: 6, title: 'Financial Statements of a Company' },
  { id: 'acc-7', subjectId: 'accountancy', number: 7, title: 'Analysis of Financial Statements' },
  { id: 'acc-8', subjectId: 'accountancy', number: 8, title: 'Cash Flow Statement' },

  // ── Business Studies ─────────────────────────────────────────────────────
  { id: 'bst-1', subjectId: 'business-studies', number: 1, title: 'Nature and Significance of Management' },
  { id: 'bst-2', subjectId: 'business-studies', number: 2, title: 'Principles of Management' },
  { id: 'bst-3', subjectId: 'business-studies', number: 3, title: 'Business Environment' },
  { id: 'bst-4', subjectId: 'business-studies', number: 4, title: 'Planning' },
  { id: 'bst-5', subjectId: 'business-studies', number: 5, title: 'Organising' },
  { id: 'bst-6', subjectId: 'business-studies', number: 6, title: 'Staffing' },
  { id: 'bst-7', subjectId: 'business-studies', number: 7, title: 'Directing' },
  { id: 'bst-8', subjectId: 'business-studies', number: 8, title: 'Financial Management' },
  { id: 'bst-9', subjectId: 'business-studies', number: 9, title: 'Marketing Management' },

  // ── Applied Mathematics ──────────────────────────────────────────────────
  { id: 'apm-1', subjectId: 'applied-maths', number: 1, title: 'Numbers and Quantification' },
  { id: 'apm-2', subjectId: 'applied-maths', number: 2, title: 'Algebra' },
  { id: 'apm-3', subjectId: 'applied-maths', number: 3, title: 'Calculus' },
  { id: 'apm-4', subjectId: 'applied-maths', number: 4, title: 'Financial Mathematics' },
  { id: 'apm-5', subjectId: 'applied-maths', number: 5, title: 'Inferential Statistics' },
]

const topics: readonly Topic[] = [
  // ── Economics ────────────────────────────────────────────────────────────
  { id: 'eco-1-a', chapterId: 'eco-1', title: 'Scarcity and choice' },
  { id: 'eco-1-b', chapterId: 'eco-1', title: 'Opportunity cost' },
  { id: 'eco-1-c', chapterId: 'eco-1', title: 'Production possibility curve' },
  { id: 'eco-1-d', chapterId: 'eco-1', title: 'Central problems of an economy' },

  { id: 'eco-2-a', chapterId: 'eco-2', title: 'Utility analysis' },
  { id: 'eco-2-b', chapterId: 'eco-2', title: 'Indifference curves' },
  { id: 'eco-2-c', chapterId: 'eco-2', title: 'Budget line' },
  { id: 'eco-2-d', chapterId: 'eco-2', title: 'Law of demand' },
  { id: 'eco-2-e', chapterId: 'eco-2', title: 'Elasticity of demand' },

  { id: 'eco-3-a', chapterId: 'eco-3', title: 'Production function' },
  { id: 'eco-3-b', chapterId: 'eco-3', title: 'Returns to a factor' },
  { id: 'eco-3-c', chapterId: 'eco-3', title: 'Cost curves' },
  { id: 'eco-3-d', chapterId: 'eco-3', title: 'Revenue and supply' },

  { id: 'eco-4-a', chapterId: 'eco-4', title: 'Perfect competition' },
  { id: 'eco-4-b', chapterId: 'eco-4', title: 'Monopoly' },
  { id: 'eco-4-c', chapterId: 'eco-4', title: 'Equilibrium price' },
  { id: 'eco-4-d', chapterId: 'eco-4', title: 'Effects of shifts in demand and supply' },

  { id: 'eco-5-a', chapterId: 'eco-5', title: 'Circular flow of income' },
  { id: 'eco-5-b', chapterId: 'eco-5', title: 'Methods of calculating national income' },
  { id: 'eco-5-c', chapterId: 'eco-5', title: 'Real and nominal GDP' },
  { id: 'eco-5-d', chapterId: 'eco-5', title: 'GDP and welfare' },

  { id: 'eco-6-a', chapterId: 'eco-6', title: 'Functions of money' },
  { id: 'eco-6-b', chapterId: 'eco-6', title: 'Money supply' },
  { id: 'eco-6-c', chapterId: 'eco-6', title: 'Credit creation' },
  { id: 'eco-6-d', chapterId: 'eco-6', title: 'Central bank and its functions' },

  { id: 'eco-7-a', chapterId: 'eco-7', title: 'Aggregate demand and supply' },
  { id: 'eco-7-b', chapterId: 'eco-7', title: 'Consumption and saving functions' },
  { id: 'eco-7-c', chapterId: 'eco-7', title: 'Investment multiplier' },
  { id: 'eco-7-d', chapterId: 'eco-7', title: 'Excess and deficient demand' },

  { id: 'eco-8-a', chapterId: 'eco-8', title: 'Objectives of a government budget' },
  { id: 'eco-8-b', chapterId: 'eco-8', title: 'Receipts and expenditure' },
  { id: 'eco-8-c', chapterId: 'eco-8', title: 'Measures of budget deficit' },

  // ── Accountancy ──────────────────────────────────────────────────────────
  { id: 'acc-1-a', chapterId: 'acc-1', title: 'Partnership deed' },
  { id: 'acc-1-b', chapterId: 'acc-1', title: 'Profit and loss appropriation' },
  { id: 'acc-1-c', chapterId: 'acc-1', title: 'Interest on capital and drawings' },
  { id: 'acc-1-d', chapterId: 'acc-1', title: "Guarantee of partner's profit" },

  { id: 'acc-2-a', chapterId: 'acc-2', title: 'Change in profit sharing ratio' },
  { id: 'acc-2-b', chapterId: 'acc-2', title: 'Goodwill valuation' },
  { id: 'acc-2-c', chapterId: 'acc-2', title: 'Admission of a partner' },
  { id: 'acc-2-d', chapterId: 'acc-2', title: 'Retirement and death of a partner' },

  { id: 'acc-3-a', chapterId: 'acc-3', title: 'Realisation account' },
  { id: 'acc-3-b', chapterId: 'acc-3', title: 'Settlement of liabilities' },
  { id: 'acc-3-c', chapterId: 'acc-3', title: 'Closing partner accounts' },

  { id: 'acc-4-a', chapterId: 'acc-4', title: 'Issue of shares' },
  { id: 'acc-4-b', chapterId: 'acc-4', title: 'Calls in arrears and advance' },
  { id: 'acc-4-c', chapterId: 'acc-4', title: 'Forfeiture and reissue' },
  { id: 'acc-4-d', chapterId: 'acc-4', title: 'Private placement and ESOP' },

  { id: 'acc-5-a', chapterId: 'acc-5', title: 'Issue of debentures' },
  { id: 'acc-5-b', chapterId: 'acc-5', title: 'Interest on debentures' },
  { id: 'acc-5-c', chapterId: 'acc-5', title: 'Redemption methods' },

  { id: 'acc-6-a', chapterId: 'acc-6', title: 'Balance sheet format' },
  { id: 'acc-6-b', chapterId: 'acc-6', title: 'Statement of profit and loss' },
  { id: 'acc-6-c', chapterId: 'acc-6', title: 'Notes to accounts' },

  { id: 'acc-7-a', chapterId: 'acc-7', title: 'Comparative statements' },
  { id: 'acc-7-b', chapterId: 'acc-7', title: 'Common size statements' },
  { id: 'acc-7-c', chapterId: 'acc-7', title: 'Accounting ratios' },

  { id: 'acc-8-a', chapterId: 'acc-8', title: 'Operating activities' },
  { id: 'acc-8-b', chapterId: 'acc-8', title: 'Investing activities' },
  { id: 'acc-8-c', chapterId: 'acc-8', title: 'Financing activities' },

  // ── Business Studies ─────────────────────────────────────────────────────
  { id: 'bst-1-a', chapterId: 'bst-1', title: 'Characteristics of management' },
  { id: 'bst-1-b', chapterId: 'bst-1', title: 'Objectives of management' },
  { id: 'bst-1-c', chapterId: 'bst-1', title: 'Levels of management' },
  { id: 'bst-1-d', chapterId: 'bst-1', title: 'Coordination' },

  { id: 'bst-2-a', chapterId: 'bst-2', title: "Fayol's principles" },
  { id: 'bst-2-b', chapterId: 'bst-2', title: 'Scientific management' },
  { id: 'bst-2-c', chapterId: 'bst-2', title: 'Techniques of Taylor' },

  { id: 'bst-3-a', chapterId: 'bst-3', title: 'Dimensions of business environment' },
  { id: 'bst-3-b', chapterId: 'bst-3', title: 'Economic reforms of 1991' },
  { id: 'bst-3-c', chapterId: 'bst-3', title: 'Impact on business' },

  { id: 'bst-4-a', chapterId: 'bst-4', title: 'Features and importance of planning' },
  { id: 'bst-4-b', chapterId: 'bst-4', title: 'Planning process' },
  { id: 'bst-4-c', chapterId: 'bst-4', title: 'Types of plans' },

  { id: 'bst-5-a', chapterId: 'bst-5', title: 'Organising process' },
  { id: 'bst-5-b', chapterId: 'bst-5', title: 'Organisation structure' },
  { id: 'bst-5-c', chapterId: 'bst-5', title: 'Delegation and decentralisation' },

  { id: 'bst-6-a', chapterId: 'bst-6', title: 'Staffing process' },
  { id: 'bst-6-b', chapterId: 'bst-6', title: 'Recruitment and selection' },
  { id: 'bst-6-c', chapterId: 'bst-6', title: 'Training and development' },

  { id: 'bst-7-a', chapterId: 'bst-7', title: 'Supervision and motivation' },
  { id: 'bst-7-b', chapterId: 'bst-7', title: 'Leadership styles' },
  { id: 'bst-7-c', chapterId: 'bst-7', title: 'Communication' },

  { id: 'bst-8-a', chapterId: 'bst-8', title: 'Capital structure' },
  { id: 'bst-8-b', chapterId: 'bst-8', title: 'Fixed and working capital' },
  { id: 'bst-8-c', chapterId: 'bst-8', title: 'Financial planning' },

  { id: 'bst-9-a', chapterId: 'bst-9', title: 'Marketing mix' },
  { id: 'bst-9-b', chapterId: 'bst-9', title: 'Branding and packaging' },
  { id: 'bst-9-c', chapterId: 'bst-9', title: 'Pricing and channels' },
  { id: 'bst-9-d', chapterId: 'bst-9', title: 'Consumer protection' },

  // ── Applied Mathematics ──────────────────────────────────────────────────
  { id: 'apm-1-a', chapterId: 'apm-1', title: 'Modulo arithmetic' },
  { id: 'apm-1-b', chapterId: 'apm-1', title: 'Ratio and proportion' },
  { id: 'apm-1-c', chapterId: 'apm-1', title: 'Numerical problems' },

  { id: 'apm-2-a', chapterId: 'apm-2', title: 'Matrices' },
  { id: 'apm-2-b', chapterId: 'apm-2', title: 'Determinants' },

  { id: 'apm-3-a', chapterId: 'apm-3', title: 'Derivatives' },
  { id: 'apm-3-b', chapterId: 'apm-3', title: 'Maxima and minima' },
  { id: 'apm-3-c', chapterId: 'apm-3', title: 'Integration' },

  { id: 'apm-4-a', chapterId: 'apm-4', title: 'Interest and annuities' },
  { id: 'apm-4-b', chapterId: 'apm-4', title: 'EMI and depreciation' },
  { id: 'apm-4-c', chapterId: 'apm-4', title: 'Bonds and returns' },

  { id: 'apm-5-a', chapterId: 'apm-5', title: 'Sampling and distributions' },
  { id: 'apm-5-b', chapterId: 'apm-5', title: 'Hypothesis testing' },
  { id: 'apm-5-c', chapterId: 'apm-5', title: 'Index numbers and time series' },
]

export const CURRICULUM: Curriculum = { subjects, chapters, topics }
