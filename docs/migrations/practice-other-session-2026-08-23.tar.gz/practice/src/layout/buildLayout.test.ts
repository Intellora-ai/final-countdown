import { describe, it, expect } from 'vitest'
import { buildLayout, endpointsOf, type Layout } from './buildLayout'
import { CURRICULUM, type Curriculum } from '@/data/curriculum'

/* THE ACCEPTANCE TEST, WRITTEN DOWN.
 *
 * The stated bar is: add one item to the data file, touch nothing else, and it
 * appears on screen correctly positioned and correctly connected. These tests
 * are that sentence turned into something a machine checks on every commit,
 * because a promise nothing executes is a promise that quietly stops being
 * true.
 *
 * They deliberately add items rather than assert against a golden snapshot. A
 * snapshot proves today's picture; adding an item proves the MECHANISM.
 */

const layout = buildLayout(CURRICULUM)

/** The curriculum plus one extra item. Never mutates the real one. */
function withExtra(extra: Partial<Curriculum>): Curriculum {
  return {
    subjects: [...CURRICULUM.subjects, ...(extra.subjects ?? [])],
    chapters: [...CURRICULUM.chapters, ...(extra.chapters ?? [])],
    topics: [...CURRICULUM.topics, ...(extra.topics ?? [])],
  }
}

const finite = (n: number) => Number.isFinite(n)

function inBounds(l: Layout, id: string): boolean {
  const n = l.byId.get(id)
  if (!n) return false
  return n.x >= l.bounds.minX && n.x <= l.bounds.maxX
    && n.y >= l.bounds.minY && n.y <= l.bounds.maxY
}

/* ── 1. adding an item makes it appear, placed and joined ────────────────── */

describe('adding an item to the data file is enough', () => {
  it('renders a new TOPIC, positioned and connected, with no other edit', () => {
    const before = layout.nodes.length
    const next = buildLayout(withExtra({
      topics: [{ id: 'eco-1-z', chapterId: 'eco-1', title: 'Fake topic' }],
    }))

    expect(next.nodes.length).toBe(before + 1)

    const added = next.byId.get('eco-1-z')
    expect(added, 'the new topic exists in the layout').toBeDefined()
    expect(finite(added!.x) && finite(added!.y), 'coordinates are finite').toBe(true)
    expect(inBounds(next, 'eco-1-z'), 'coordinates are inside the measured bounds').toBe(true)

    /* Connected to the right parent, and near it — a node that landed in the
     * correct list but the wrong place is still a failure. */
    expect(added!.parentId).toBe('eco-1')
    const parent = next.byId.get('eco-1')!
    const distance = Math.hypot(added!.x - parent.x, added!.y - parent.y)
    expect(distance, 'sits on its chapter ring').toBeGreaterThan(0)
    expect(distance, 'sits on its chapter ring').toBeLessThan(200)

    expect(next.edges.some((e) => e.from === 'eco-1' && e.to === 'eco-1-z')).toBe(true)
  })

  it('renders a new CHAPTER, positioned and connected', () => {
    const next = buildLayout(withExtra({
      chapters: [{ id: 'eco-99', subjectId: 'economics', number: 99, title: 'Fake chapter' }],
    }))
    const added = next.byId.get('eco-99')
    expect(added).toBeDefined()
    expect(finite(added!.x) && finite(added!.y)).toBe(true)
    expect(inBounds(next, 'eco-99')).toBe(true)
    expect(added!.parentId).toBe('economics')
    expect(next.edges.some((e) => e.from === 'economics' && e.to === 'eco-99')).toBe(true)
  })

  it('renders a new SUBJECT with its own chapter, and re-spaces the others', () => {
    /* The hardest case: a new top-level cluster. Nothing in the data says
     * where any subject goes, so all five must redistribute. */
    const next = buildLayout(withExtra({
      subjects: [{ id: 'entrepreneurship', name: 'Entrepreneurship' }],
      chapters: [{ id: 'ent-1', subjectId: 'entrepreneurship', number: 1, title: 'Fake' }],
    }))

    expect(next.byId.get('entrepreneurship')).toBeDefined()
    expect(inBounds(next, 'entrepreneurship')).toBe(true)
    expect(next.edges.some((e) => e.from === 'entrepreneurship' && e.to === 'ent-1')).toBe(true)

    /* Every existing subject moved, because the ring is divided by count. If
     * any had stayed put it would mean its position was written down. */
    const movedCount = CURRICULUM.subjects.filter((s) => {
      const a = layout.byId.get(s.id)!
      const b = next.byId.get(s.id)!
      return a.x !== b.x || a.y !== b.y
    }).length
    expect(movedCount, 'existing subjects re-space around the new one').toBeGreaterThan(0)
  })

  it('keeps every coordinate finite and in bounds for the whole real curriculum', () => {
    for (const n of layout.nodes) {
      expect(finite(n.x) && finite(n.y), `${n.id} coordinates`).toBe(true)
      expect(inBounds(layout, n.id), `${n.id} within bounds`).toBe(true)
    }
    expect(layout.bounds.width).toBeGreaterThan(0)
    expect(layout.bounds.height).toBeGreaterThan(0)
  })
})

/* ── 2. determinism ──────────────────────────────────────────────────────── */

describe('the layout is deterministic', () => {
  it('buildLayout(data) equals buildLayout(data)', () => {
    const a = buildLayout(CURRICULUM)
    const b = buildLayout(CURRICULUM)
    expect(a.nodes).toEqual(b.nodes)
    expect(a.edges).toEqual(b.edges)
    expect(a.bounds).toEqual(b.bounds)
  })

  it('gives identical coordinates across many rebuilds', () => {
    /* Ten rebuilds, not two: a single repeat would pass even if the second
     * call were memoised rather than genuinely deterministic. */
    const runs = Array.from({ length: 10 }, () => buildLayout(CURRICULUM))
    const signature = (l: Layout) => l.nodes.map((n) => `${n.id}:${n.x}:${n.y}`).join('|')
    const first = signature(runs[0]!)
    for (const r of runs) expect(signature(r)).toBe(first)
  })

  it('does not depend on the order items appear in the data file', () => {
    /* Position comes from the id, so shuffling the arrays must move nothing.
     * Reversal is a fixed permutation, so this stays deterministic itself. */
    const reversed: Curriculum = {
      subjects: CURRICULUM.subjects,
      chapters: [...CURRICULUM.chapters].reverse(),
      topics: [...CURRICULUM.topics].reverse(),
    }
    const next = buildLayout(reversed)
    for (const n of layout.nodes) {
      const m = next.byId.get(n.id)!
      expect(m.x, `${n.id} x`).toBe(n.x)
      expect(m.y, `${n.id} y`).toBe(n.y)
    }
  })

  it('uses no Math.random at build time', () => {
    const real = Math.random
    Math.random = () => { throw new Error('buildLayout called Math.random()') }
    try {
      expect(() => buildLayout(CURRICULUM)).not.toThrow()
    } finally {
      Math.random = real
    }
  })
})

/* ── 3. edges are complete and never dangle ──────────────────────────────── */

describe('every child is joined to its parent, and no edge dangles', () => {
  it('gives every non-subject node exactly one edge from its parent', () => {
    for (const node of layout.nodes) {
      if (node.kind === 'subject') continue
      const incoming = layout.edges.filter((e) => e.to === node.id)
      expect(incoming.length, `${node.id} incoming edges`).toBe(1)
      expect(incoming[0]!.from, `${node.id} parent`).toBe(node.parentId)
    }
  })

  it('points every edge at a node that exists', () => {
    for (const edge of layout.edges) {
      expect(layout.byId.has(edge.from), `edge ${edge.id} from`).toBe(true)
      expect(layout.byId.has(edge.to), `edge ${edge.id} to`).toBe(true)
      expect(endpointsOf(layout, edge), `edge ${edge.id} resolves`).not.toBeNull()
    }
  })

  it('drops an item whose parent does not exist, and says so', () => {
    /* The alternative is an edge into empty space. Reported, not silent. */
    const next = buildLayout(withExtra({
      topics: [{ id: 'ghost', chapterId: 'no-such-chapter', title: 'Ghost' }],
    }))
    expect(next.byId.has('ghost')).toBe(false)
    expect(next.orphans).toContain('ghost')
    expect(next.edges.some((e) => e.to === 'ghost' || e.from === 'ghost')).toBe(false)
    for (const edge of next.edges) {
      expect(endpointsOf(next, edge)).not.toBeNull()
    }
  })

  it('has one edge per child and no more', () => {
    const children = layout.nodes.filter((n) => n.parentId !== null).length
    expect(layout.edges.length).toBe(children)
  })

  it('carries no coordinates on the edge itself', () => {
    /* The rule that stops a line pointing at where a node used to be: an edge
     * stores ids, and the renderer resolves them against the same byId map the
     * nodes came from. A coordinate here would be a second source of truth. */
    for (const edge of layout.edges) {
      expect(Object.keys(edge).sort()).toEqual(['from', 'id', 'to'])
    }
  })
})

/* ── 4. the data file states no geometry ─────────────────────────────────── */

describe('the data file holds no positions', () => {
  it('has no x, y, angle, radius or size on any item', () => {
    const banned = ['x', 'y', 'cx', 'cy', 'left', 'top', 'angle', 'radius', 'r', 'width', 'height']
    const items = [...CURRICULUM.subjects, ...CURRICULUM.chapters, ...CURRICULUM.topics]
    for (const item of items) {
      for (const key of Object.keys(item)) {
        expect(banned, `${(item as { id: string }).id} declares "${key}"`).not.toContain(key)
      }
    }
  })

  it('gives every chapter a real subject and every topic a real chapter', () => {
    const subjectIds = new Set(CURRICULUM.subjects.map((s) => s.id))
    const chapterIds = new Set(CURRICULUM.chapters.map((c) => c.id))
    for (const c of CURRICULUM.chapters) expect(subjectIds.has(c.subjectId), c.id).toBe(true)
    for (const t of CURRICULUM.topics) expect(chapterIds.has(t.chapterId), t.id).toBe(true)
    expect(layout.orphans).toEqual([])
  })

  it('uses a unique id for every item', () => {
    const ids = [...CURRICULUM.subjects, ...CURRICULUM.chapters, ...CURRICULUM.topics]
      .map((i) => i.id)
    expect(new Set(ids).size, 'duplicate id in the curriculum').toBe(ids.length)
  })
})
