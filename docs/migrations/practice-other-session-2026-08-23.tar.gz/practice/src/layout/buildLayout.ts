import type { Curriculum } from '@/data/curriculum'

/* THE ONLY PLACE A POSITION IS EVER DECIDED.
 *
 * A pure function: curriculum in, coordinates out. No clock, no
 * Math.random(), no module-level mutable state, no reading of window. Call it
 * a thousand times with the same data and you get a thousand identical
 * answers, which is what makes the map stable across reloads without storing a
 * single coordinate anywhere.
 *
 * WHERE THE RANDOMNESS COMES FROM. The constellation needs to look scattered
 * rather than mechanical, and scatter normally means Math.random() — which
 * would reposition every node on every render and make the map a different
 * picture each reload. Instead each node derives its own jitter from a hash of
 * its OWN id. `eco-3-b` always lands in exactly the same place because its
 * name is `eco-3-b`, not because of where it sits in an array. Reordering the
 * data file changes nothing; renaming an id is what moves a node.
 *
 * WHY EDGES CARRY IDS AND NOT COORDINATES. An edge here is `{from, to}` and
 * nothing else. The renderer looks both endpoints up in `byId`, so a line
 * physically cannot point at where a node used to be — there is no second copy
 * of the position to go stale. This is the one rule that keeps a connector
 * honest, and it is why LayoutEdge has no x or y on it.
 *
 * THE CONSTANTS BELOW ARE NOT A COORDINATE TABLE. `SUBJECT_ORBIT_X` is a
 * parameter of the algorithm, the way a font size is a parameter of a type
 * scale — it describes how ALL subjects are spread, not where any particular
 * one goes. A coordinate table would name `economics` and give it a number.
 * Nothing here names an item. That distinction is the whole point: adding a
 * fifth subject re-spaces the other four automatically, because no subject's
 * position was ever written down.
 */

export type NodeKind = 'subject' | 'chapter' | 'topic'

export interface LayoutNode {
  readonly id: string
  readonly kind: NodeKind
  readonly label: string
  /** Chapter -> subject, topic -> chapter, subject -> null. */
  readonly parentId: string | null
  /** Which cluster this belongs to, for colour and filtering. */
  readonly subjectId: string
  readonly x: number
  readonly y: number
  /** Drawn radius, derived from kind. Renderers must not invent their own. */
  readonly r: number
  /** Chapter number for a chapter node, so the label can read "CH 3". */
  readonly chapterNumber: number | null
}

/** Ids only. Deliberately no coordinates — see the header. */
export interface LayoutEdge {
  readonly id: string
  readonly from: string
  readonly to: string
}

export interface LayoutBounds {
  readonly minX: number
  readonly minY: number
  readonly maxX: number
  readonly maxY: number
  readonly width: number
  readonly height: number
}

export interface Layout {
  readonly nodes: readonly LayoutNode[]
  readonly edges: readonly LayoutEdge[]
  readonly byId: ReadonlyMap<string, LayoutNode>
  readonly childrenOf: ReadonlyMap<string, readonly LayoutNode[]>
  readonly bounds: LayoutBounds
  /** Items whose parent does not exist. Reported, never silently dropped. */
  readonly orphans: readonly string[]
}

/* ── algorithm parameters, not positions ─────────────────────────────────── */

const SUBJECT_ORBIT_X = 620
const SUBJECT_ORBIT_Y = 300
const CHAPTER_ORBIT = 240
const CHAPTER_JITTER = 0.42
const TOPIC_ORBIT = 78
const TOPIC_JITTER = 0.34
const RADIUS: Record<NodeKind, number> = { subject: 0, chapter: 5.5, topic: 2.6 }
const PADDING = 160
const TAU = Math.PI * 2
/** Positions are rounded so a float that differs in its last bit cannot make
 *  two otherwise identical layouts compare unequal. */
const PRECISION = 1e4

/* ── deterministic pseudo-randomness, seeded per id ──────────────────────── */

/** FNV-1a. Same string in, same uint32 out, on every engine and every run. */
function hashId(id: string): number {
  let h = 2166136261 >>> 0
  for (let i = 0; i < id.length; i++) {
    h ^= id.charCodeAt(i)
    h = Math.imul(h, 16777619) >>> 0
  }
  return h >>> 0
}

/** mulberry32, seeded from the id's hash. Returns values in [0, 1). */
function rngFor(id: string): () => number {
  let a = hashId(id)
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const round = (n: number): number => Math.round(n * PRECISION) / PRECISION

/* ── the layout ──────────────────────────────────────────────────────────── */

export function buildLayout(data: Curriculum): Layout {
  const nodes: LayoutNode[] = []
  const edges: LayoutEdge[] = []
  const orphans: string[] = []
  const byId = new Map<string, LayoutNode>()

  const push = (n: LayoutNode) => { nodes.push(n); byId.set(n.id, n) }

  /* SUBJECTS — evenly spaced on an ellipse, angle from index so that adding a
   * subject re-spaces every other one instead of colliding with them. The
   * ellipse is wider than tall because screens are. */
  const subjectCount = Math.max(1, data.subjects.length)
  const subjectCentre = new Map<string, { x: number; y: number }>()

  data.subjects.forEach((subject, i) => {
    /* -TAU/4 puts the first subject at the top rather than at 3 o'clock, so a
     * two-subject curriculum reads as above/below instead of side-by-side. */
    const angle = -TAU / 4 + (i * TAU) / subjectCount
    const x = round(Math.cos(angle) * SUBJECT_ORBIT_X)
    const y = round(Math.sin(angle) * SUBJECT_ORBIT_Y)
    subjectCentre.set(subject.id, { x, y })
    push({
      id: subject.id, kind: 'subject', label: subject.name,
      parentId: null, subjectId: subject.id, x, y,
      r: RADIUS.subject, chapterNumber: null,
    })
  })

  /* CHAPTERS — a ring around their own subject. The ring's starting angle is
   * seeded from the SUBJECT's id so two clusters do not line up identically,
   * and each chapter's distance is seeded from its OWN id so the ring reads as
   * a constellation rather than a clock face. */
  /* SIBLINGS ARE SORTED, NOT TAKEN IN ARRAY ORDER.
   *
   * The first cut used `indexOf` into the data array to pick a ring slot, and
   * a test caught it immediately: reversing the chapters array moved eco-1
   * from x=71 to x=190. Position would have depended on where a line happened
   * to sit in the file, so inserting a chapter in the middle would have
   * silently shuffled every sibling after it.
   *
   * Chapters order by their printed number so the ring reads 1, 2, 3 the way a
   * textbook does, with the id as tie-break. Topics have no number, so they
   * order by id. Either way the slot is a property of the ITEM, and editing
   * the file's line order changes nothing on screen. */
  const chaptersBySubject = new Map<string, string[]>()
  const chapterOrder = new Map<string, number>()
  for (const chapter of data.chapters) chapterOrder.set(chapter.id, chapter.number)
  for (const chapter of data.chapters) {
    const list = chaptersBySubject.get(chapter.subjectId)
    if (list) list.push(chapter.id)
    else chaptersBySubject.set(chapter.subjectId, [chapter.id])
  }
  for (const list of chaptersBySubject.values()) {
    list.sort((a, b) => {
      const byNumber = (chapterOrder.get(a) ?? 0) - (chapterOrder.get(b) ?? 0)
      return byNumber !== 0 ? byNumber : a.localeCompare(b)
    })
  }

  for (const chapter of data.chapters) {
    const centre = subjectCentre.get(chapter.subjectId)
    if (!centre) { orphans.push(chapter.id); continue }

    const siblings = chaptersBySubject.get(chapter.subjectId) ?? []
    const index = siblings.indexOf(chapter.id)
    const count = Math.max(1, siblings.length)

    const ringOffset = rngFor(chapter.subjectId)() * TAU
    const own = rngFor(chapter.id)
    /* Angular jitter stays under half a slot so a chapter can never overtake
     * its neighbour and make the ring order unreadable. */
    const slot = TAU / count
    const angle = ringOffset + index * slot + (own() - 0.5) * slot * 0.55
    const radius = CHAPTER_ORBIT * (1 - CHAPTER_JITTER / 2 + own() * CHAPTER_JITTER)

    push({
      id: chapter.id, kind: 'chapter', label: chapter.title,
      parentId: chapter.subjectId, subjectId: chapter.subjectId,
      x: round(centre.x + Math.cos(angle) * radius),
      y: round(centre.y + Math.sin(angle) * radius),
      r: RADIUS.chapter, chapterNumber: chapter.number,
    })
    edges.push({ id: `${chapter.subjectId}->${chapter.id}`, from: chapter.subjectId, to: chapter.id })
  }

  /* TOPICS — a small ring around their own chapter, same construction one
   * level down. A topic is positioned whether or not its chapter is currently
   * expanded: visibility is the renderer's business, not the layout's. */
  const topicsByChapter = new Map<string, string[]>()
  for (const topic of data.topics) {
    const list = topicsByChapter.get(topic.chapterId)
    if (list) list.push(topic.id)
    else topicsByChapter.set(topic.chapterId, [topic.id])
  }
  /* Sorted for the same reason chapters are: the slot must belong to the item,
   * not to its line number in the data file. */
  for (const list of topicsByChapter.values()) list.sort((a, b) => a.localeCompare(b))

  for (const topic of data.topics) {
    const parent = byId.get(topic.chapterId)
    if (!parent || parent.kind !== 'chapter') { orphans.push(topic.id); continue }

    const siblings = topicsByChapter.get(topic.chapterId) ?? []
    const index = siblings.indexOf(topic.id)
    const count = Math.max(1, siblings.length)

    const ringOffset = rngFor(topic.chapterId)() * TAU
    const own = rngFor(topic.id)
    const slot = TAU / count
    const angle = ringOffset + index * slot + (own() - 0.5) * slot * 0.4
    const radius = TOPIC_ORBIT * (1 - TOPIC_JITTER / 2 + own() * TOPIC_JITTER)

    push({
      id: topic.id, kind: 'topic', label: topic.title,
      parentId: topic.chapterId, subjectId: parent.subjectId,
      x: round(parent.x + Math.cos(angle) * radius),
      y: round(parent.y + Math.sin(angle) * radius),
      r: RADIUS.topic, chapterNumber: null,
    })
    edges.push({ id: `${topic.chapterId}->${topic.id}`, from: topic.chapterId, to: topic.id })
  }

  /* CHILDREN, indexed once. Every consumer that needs "the topics of this
   * chapter" reads this rather than re-deriving it and risking a different
   * answer. */
  const childrenOf = new Map<string, LayoutNode[]>()
  for (const node of nodes) {
    if (!node.parentId) continue
    const list = childrenOf.get(node.parentId)
    if (list) list.push(node)
    else childrenOf.set(node.parentId, [node])
  }
  /* Sorted too, so a list rendered from this cannot reshuffle when the data
   * file is reordered. Chapters by number, everything else by id. */
  for (const list of childrenOf.values()) {
    list.sort((a, b) => {
      if (a.chapterNumber !== null && b.chapterNumber !== null) {
        const byNumber = a.chapterNumber - b.chapterNumber
        if (byNumber !== 0) return byNumber
      }
      return a.id.localeCompare(b.id)
    })
  }

  /* BOUNDS are measured from the nodes, never declared. There is no 1408x768
   * anywhere: the world is exactly as big as the content in it, so adding a
   * subject grows the map instead of pushing it off a fixed edge. */
  const bounds = measure(nodes)

  return { nodes, edges, byId, childrenOf, bounds, orphans }
}

function measure(nodes: readonly LayoutNode[]): LayoutBounds {
  if (nodes.length === 0) {
    return { minX: 0, minY: 0, maxX: 0, maxY: 0, width: 0, height: 0 }
  }
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const n of nodes) {
    minX = Math.min(minX, n.x - n.r)
    minY = Math.min(minY, n.y - n.r)
    maxX = Math.max(maxX, n.x + n.r)
    maxY = Math.max(maxY, n.y + n.r)
  }
  minX -= PADDING; minY -= PADDING; maxX += PADDING; maxY += PADDING
  return {
    minX: round(minX), minY: round(minY), maxX: round(maxX), maxY: round(maxY),
    width: round(maxX - minX), height: round(maxY - minY),
  }
}

/** Resolve an edge to two nodes. Returns null when either end is missing, so a
 *  renderer cannot draw a line to nowhere even if the data is broken. */
export function endpointsOf(
  layout: Layout, edge: LayoutEdge,
): { from: LayoutNode; to: LayoutNode } | null {
  const from = layout.byId.get(edge.from)
  const to = layout.byId.get(edge.to)
  return from && to ? { from, to } : null
}
