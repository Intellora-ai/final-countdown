'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

/* WHAT THE STUDENT LEAVES BEHIND BETWEEN VISITS.
 *
 * Three things, and no positions among them. Positions come from
 * buildLayout(); putting one here would be the second source of truth the
 * whole design exists to avoid, and a stale saved coordinate would survive a
 * curriculum edit and point a line at nothing.
 *
 * EXPANSION IS REMEMBERED PER CHAPTER, because the brief asked for it
 * explicitly: hovering opens a chapter, and whatever the student leaves open
 * or closed is how they find it next time. `expanded` therefore holds only the
 * chapters that have been deliberately toggled — a chapter absent from the map
 * has never been touched and uses the default. Storing every chapter's state
 * eagerly would freeze today's curriculum into localStorage and leave newly
 * added chapters invisible until the student cleared their browser.
 */

export interface PracticePrefs {
  /** Whether the countdown is on at all. */
  readonly timerOn: boolean
  /** Minutes. One of the offered presets. */
  readonly timerMinutes: number
  /** How many questions a session asks. Capped at QUESTION_MAX. */
  readonly questionCount: number
}

/** The brief settled on fifteen after considering twenty. */
export const QUESTION_MAX = 15
export const QUESTION_MIN = 1
export const TIMER_PRESETS = [5, 10, 15, 20, 30] as const

export interface PracticeState {
  /** Chapter id -> expanded. Absent means "never touched, use the default". */
  readonly expanded: Readonly<Record<string, boolean>>
  /** Chapter id -> ISO timestamp of the last completed session. */
  readonly lastPractised: Readonly<Record<string, string>>
  /** Topic ids the student has practised at least once. */
  readonly practisedTopics: readonly string[]
  readonly prefs: PracticePrefs

  toggleChapter: (chapterId: string) => void
  setChapterExpanded: (chapterId: string, open: boolean) => void
  markPractised: (chapterId: string, topicIds: readonly string[], atIso: string) => void
  setPrefs: (patch: Partial<PracticePrefs>) => void
}

const DEFAULT_PREFS: PracticePrefs = { timerOn: true, timerMinutes: 10, questionCount: 10 }

/** Clamp rather than reject: a slider cannot produce a sensible error message,
 *  and a persisted value from an older build must not brick the panel. */
const clampQuestions = (n: number): number =>
  Math.min(QUESTION_MAX, Math.max(QUESTION_MIN, Math.round(Number.isFinite(n) ? n : QUESTION_MIN)))

export const usePracticeStore = create<PracticeState>()(
  persist(
    (set) => ({
      expanded: {},
      lastPractised: {},
      practisedTopics: [],
      prefs: DEFAULT_PREFS,

      toggleChapter: (chapterId) =>
        set((s) => ({ expanded: { ...s.expanded, [chapterId]: !s.expanded[chapterId] } })),

      setChapterExpanded: (chapterId, open) =>
        set((s) => (s.expanded[chapterId] === open
          ? s
          : { expanded: { ...s.expanded, [chapterId]: open } })),

      markPractised: (chapterId, topicIds, atIso) =>
        set((s) => ({
          lastPractised: { ...s.lastPractised, [chapterId]: atIso },
          practisedTopics: [...new Set([...s.practisedTopics, ...topicIds])],
        })),

      setPrefs: (patch) =>
        set((s) => ({
          prefs: {
            ...s.prefs,
            ...patch,
            ...(patch.questionCount !== undefined
              ? { questionCount: clampQuestions(patch.questionCount) }
              : {}),
          },
        })),
    }),
    {
      name: 'practice-state',
      version: 1,
      /* Only the durable half is written. Nothing derived, nothing positional. */
      partialize: (s) => ({
        expanded: s.expanded,
        lastPractised: s.lastPractised,
        practisedTopics: s.practisedTopics,
        prefs: s.prefs,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<PracticeState>
        return {
          ...current,
          ...p,
          /* A preference file written by an older build may be missing keys or
           * hold an out-of-range count. Defaults fill the gaps and the count is
           * re-clamped, so a stale store degrades instead of breaking. */
          prefs: {
            ...DEFAULT_PREFS,
            ...(p.prefs ?? {}),
            questionCount: clampQuestions(p.prefs?.questionCount ?? DEFAULT_PREFS.questionCount),
          },
        }
      },
    },
  ),
)
